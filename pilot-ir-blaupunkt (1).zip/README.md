
# Pilot IR - Blaupunkt BN40F1132EEB

Aplikacja Android do sterowania TV Blaupunkt przez wbudowany nadajnik IR.

### Build APK przez GitHub Actions
1. Wrzuć to repo na GitHub
2. Wejdź w zakładkę Actions
3. Poczekaj 2-3 min aż skończy się build
4. Pobierz artifact "app-debug" - tam jest APK

### Wymagania
Telefon z nadajnikiem IR. Działa na Xiaomi, Huawei, Honor, starsze Samsung/LG.
